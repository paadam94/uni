int sum(int n)
{
    if (n==4)
        return 2 * (4-2) * (4-2);
    else
        return 2* (n-2) * (n-3);
}
