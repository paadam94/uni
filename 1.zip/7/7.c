int max(int t[]){
for(int i = 0; 
}
