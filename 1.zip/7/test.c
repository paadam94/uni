#include<stdio.h>

int max(int t[]){
    int size = sizeof t / sizeof t[0];
    return size;
}
