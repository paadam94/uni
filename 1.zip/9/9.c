int sumi(int n){
    int sum = 0;
    for(int i=3; i = n; i++)
        sum += 3 * (i - 2) * (i - 2); 
    return sum;
    }
