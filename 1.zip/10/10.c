int a = 7;
int sum=0;
do
sum += a+2*a;
while( a <= 12);
printf("Sum=%d", sum);
